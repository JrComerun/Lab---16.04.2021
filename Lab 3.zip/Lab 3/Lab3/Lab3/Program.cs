﻿using System;
using System.Collections.Generic;

namespace Lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            Library elibrary = new Library();
            elibrary.Name = "ELibrary";
            Book book1 = new Book();
            book1.Name = "Sefiller";
            book1.Author = "Victor Hugo";
            book1.Price = 15.5;
            elibrary.AddBook(book1);
            Book book2 = new Book();
            book2.Name = "Kitab1";
            book2.Author = "Victor Hugo";
            book2.Price = 15.5;
            elibrary.AddBook(book2);
            Book book3 = new Book();
            book3.Name = "Kitab2";
            book3.Author = "Victor Hugo";
            book3.Price = 15.5;
            elibrary.AddBook(book3);





            elibrary.FindBookForName("sd");
            //elibrary.ShowBook();


        }
    }
}
