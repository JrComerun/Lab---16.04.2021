﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    class Library
    {
        public int Id { get; set; }
        private static int id;
        public DateTime? Deletetime { get; set; }
        public string Name { get; set; }
        public bool IsDelete { get; set; }

        public List<Book> Books { get; set; }
        public Library()
        {
            id++;
            Id = id;
            Books = new List<Book>();
        }
        public void AddBook(Book book)
        {
            Books.Add(book);

        }
        public void ShowBook()
        {
            foreach (Book book in Books)
            {
                if (book.IsDelete == true)
                {
                    Console.WriteLine($"Id: {book.Id}, Name: {book.Name}, Author: {book.Author}, Language: {book.Language}, Price: {book.Price},");

                }
            }
        }
        public Book FindBook(int id)
        {
            Book book = Books.Find(sdsd=>sdsd.Id==id);
            return book;
        }
        public void DeleteBook(int id)
        {
            Book book = FindBook(id);
            book.IsDelete = true;
            book.Deletetime = DateTime.Now;
        }
        public void FindBookForName(string name)
        {
            bool isExist = false;
            foreach (Book b in Books)
            {
                if (b.Name == name)
                {
                    Console.WriteLine($"Id: {b.Id} ,Name : {b.Name} ");
                    isExist = true;
                }
            }
            if (!isExist)
            {
                Console.WriteLine("Kitab Tapilmadi");
            }
        }
    }
}
