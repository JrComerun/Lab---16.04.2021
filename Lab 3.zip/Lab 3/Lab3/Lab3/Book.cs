﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    class Book
    {
        public int Id { get; set; }

        private static int id;
        public string Name { get; set; }
        public string Author { get; set; }
        public string Language { get; set; }
        public double Price { get; set; }
        public bool IsDelete { get; set; }
        public DateTime? Deletetime { get; set; }
        public Book()
        {
            id++;
            Id = id;
        }
    }
}
